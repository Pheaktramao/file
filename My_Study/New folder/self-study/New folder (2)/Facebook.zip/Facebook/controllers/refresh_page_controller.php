<!-- REFRESH PAGE TO THE TOP OF PAGE -->

<?php session_start();

    header("refresh:0; url=../views/home_view.php")

?>