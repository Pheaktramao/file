<?php
require "views/welcome/welcome.view.php";
?>