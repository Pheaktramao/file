<?php 
	/*Enter your API_KEY*/
	define("API_KEY", '');

	/*You can enter mobile number here*/
	define("MOBILE", '');
 ?>