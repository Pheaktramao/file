<?php

require "views/checkout/checkout.view.php";