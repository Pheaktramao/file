<?php

require "views/admin/admin.view.php";