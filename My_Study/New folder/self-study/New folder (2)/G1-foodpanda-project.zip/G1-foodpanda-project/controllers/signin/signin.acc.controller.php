<?php
session_start();
if (isset($_POST['email']) && isset($_POST['pwd'])){
    $_SESSION['email'] = $_POST['email'];
    $_SESSION['pwd'] = $_POST['pwd'];
    header('Location: /');
}