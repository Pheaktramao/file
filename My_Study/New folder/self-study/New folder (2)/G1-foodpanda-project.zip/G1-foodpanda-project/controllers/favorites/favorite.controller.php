<?php

require "views/favorites/favorite.view.php";