<?php
require "../../database/database.php";
require "../../models/employee.model.php";


deleteFromList();
header('Location: /');
