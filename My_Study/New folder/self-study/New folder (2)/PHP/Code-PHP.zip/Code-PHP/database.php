<?php
// CONNECT TO DATABASE 
$db = new PDO ('mysql:host=localhost;dbname=extra','root',"",);
