<?php
require "views/restaurant_owner/edit_restaurant.view.php";