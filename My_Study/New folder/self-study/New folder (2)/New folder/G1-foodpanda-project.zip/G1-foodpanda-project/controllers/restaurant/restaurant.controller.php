<?php

require "views/restaurant/restaurant.view.php";