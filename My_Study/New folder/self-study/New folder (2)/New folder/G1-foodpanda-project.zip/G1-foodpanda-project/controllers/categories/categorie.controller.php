<?php
require "views/categories/categories.view.php";