<?php
require "database/database.php";
require "views/resetPassword/forget_Password.view.php";

// -----------------Code to send to email to reset new password--------------------
