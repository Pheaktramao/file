<?php

require "views/restaurant_owner/categories.view.php";