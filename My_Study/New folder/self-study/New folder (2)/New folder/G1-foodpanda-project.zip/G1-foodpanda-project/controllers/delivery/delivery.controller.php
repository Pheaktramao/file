<?php

require "views/delevery/delevery.view.php";