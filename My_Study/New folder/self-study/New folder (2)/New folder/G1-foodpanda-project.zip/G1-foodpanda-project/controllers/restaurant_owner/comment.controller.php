<?php
require "views/restaurant_owner/comment.view.php";