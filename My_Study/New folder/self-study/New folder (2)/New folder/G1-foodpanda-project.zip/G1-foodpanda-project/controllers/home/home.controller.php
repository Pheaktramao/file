<?php

require "views/home/home.view.php";