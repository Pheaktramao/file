<?php
require "views/restaurant_owner/restaurant.map.php";