<?php

require "views/restaurant_owner/resetaurant_owner.view.php";