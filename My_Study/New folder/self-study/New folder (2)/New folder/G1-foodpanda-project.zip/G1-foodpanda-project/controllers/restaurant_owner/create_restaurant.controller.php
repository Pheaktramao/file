<?php

require "views/restaurant_owner/create_restaurant.view.php";