

<style>
    .map-container{
  overflow:hidden;
  padding-bottom:40%;
  position:relative;
  height:0;
}
.map-container iframe{
  left:0;
  top:0;
  height:100%;
  width:100%;
  position:absolute;
}

</style>

<!--Google map-->
<div id="map-container-google-1" class="z-depth-1-half map-container" style="height: 300px">
  <iframe src="https://maps.google.com/maps?q=manhatan&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0"
    style="border:0" allowfullscreen></iframe>
</div>

<!--Google Maps-->
