<?php

$heading = "Home Page";

require "views/admin/admin.view.php";