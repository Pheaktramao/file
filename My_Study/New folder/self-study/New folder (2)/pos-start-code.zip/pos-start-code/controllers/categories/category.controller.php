<?php
require "views/categories/category.view.php";