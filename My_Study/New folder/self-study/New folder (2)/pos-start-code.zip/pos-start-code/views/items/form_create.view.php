<div class="m-4">
    <form action="controller/items/create.controller" method = "post">
        <div class="form-group">
            <label for="title">Title:</label>
            <input type="text" class="form-control" placeholder="Enter Title" id="title">
        </div>
        <div class="form-group">
            <label for="desc">Description:</label>
            <input type="desc" class="form-control" placeholder="Enter Description" id="desc">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>

</div>