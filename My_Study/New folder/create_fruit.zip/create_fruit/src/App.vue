<template>
  <div class="cotain_table">
    <table class="table caption-top">
  <caption>List of users and fruit</caption>
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Phone Number</th>
      <th scope="col">Email</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <tr v-for="(user, index) in profile" :key="index">
      <th scope="row">{{index + 1}}</th>
      <td>{{ user.fname }}</td>
      <td>{{ user.lname }}</td>
      <td>{{user.phone}}</td>
      <td>{{user.email}}</td>
      <td id="c-btn">
        <button class="btn btn-success">Edit</button>
        <button class="btn btn-danger" @click="deleteUser(index)">Delete</button>
      </td>
    </tr>
  </tbody>
</table>
  </div>
  <div class="contain-card" id="c-card">
    <div v-for="(card, index) in fruits" :key="index" class="card" style="width: 18rem;">
      <img :src="card.imgSrc" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">{{ card.frname }}</h5>
        <p class="card-text">{{ card.description }}</p>
        <a href="#" class="btn btn-success">Buy Now</a>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "App",
  data() {
    return {
      profile: [
        {fname: "Chuon", lname: "Veasna", phone: "012-123-123-5", email: "chuonveasna123@gmail.com"},
        {fname: "Ly", lname: "SreyLuch", phone: "012-123-123-5", email: "sreyluchly123@gmail.com"},
        {fname: "Houy", lname: "Thea Rith", phone: "012-123-123-5", email: "rithrith123@gmail.com"},
        {fname: "Soy", lname: "Love", phone: "012-123-123-5", email: "soysoypumli@gmail.com"},
        {fname: "Sanok", lname: "Payang", phone: "012-123-123-5", email: "noknoklove@gmail.com"},
      ],
      fruits: [
        {imgSrc: "https://previews.123rf.com/images/kolesnikovserg/kolesnikovserg2207/kolesnikovserg220700140/189052184-lychee-fruit-in-wicker-basket-isolated-on-white-background-with-full-depth-of-field.jpg" ,frname: "Kulen", description: "Sweet and have a lot vitamince"},
        {imgSrc: "https://www.shutterstock.com/image-photo/bunch-bananas-isolated-on-white-600nw-1722111529.jpg" ,frname: "Banana", description: "Sweet and have a lot vitamince"},
        {imgSrc: "https://img1.exportersindia.com/product_images/bc-full/2021/12/5037340/fresh-coconut-1639644702-6119066.jpeg" ,frname: "Cucunut", description: "Sweet and have a lot vitamince"},
        {imgSrc: "https://d2j6dbq0eux0bg.cloudfront.net/images/36191302/1644929205.jpg" ,frname: "Green Apple", description: "Sweet and have a lot vitamince"},
      ]
    }
  },
  methods: {
    deleteUser(index) {
      this.profile.splice(index, 1);
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  #c-card{
    display: flex;
    flex: wrap;
    gap: 3%;
  }

  #c-btn{
    display: flex;
    gap: 10px;
}
</style>
