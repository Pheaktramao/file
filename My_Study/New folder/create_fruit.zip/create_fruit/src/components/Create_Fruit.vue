<template>
  <div class="cotain_table">
    <table class="table caption-top">
  <caption>List of users</caption>
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Email</th>
    </tr>
  </thead>
  <tbody>
    <tr v-for="(user, index) in profile" :key="index">
      <th scope="row">{{index + 1}}</th>
      <td>{{ user.fname }}</td>
      <td>{{ user.lname }}</td>
      <td>{{user.email}}</td>
    </tr>
  </tbody>
</table>
  </div>
</template>

<script>
export default {
  name: 'Create_Fruit',
  data() {
    return {
      profile: [
        {fname: "Chuon", lname: "Veasna", email: "chuonveasna123@gmail.com"},
        {fname: "Ly", lname: "SreyLuch", email: "sreyluchly123@gmail.com"},
        {fname: "Houy", lname: "Thea Rith", email: "rithrith123@gmail.com"},
        {fname: "Soy", lname: "Love", email: "soysoypumli@gmail.com"},
        {fname: "Sanok", lname: "Payang", email: "noknoklove@gmail.com"},
      ],
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
