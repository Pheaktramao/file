<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StudentRequest;
use App\Http\Resources\ShowStudentResource;
use App\Http\Resources\StudentResource;
use App\Models\Student;
use Illuminate\Http\Request;

class StudentController extends Controller
{

    public function index(Request  $request)
    {
        $this->params = $request->only('search');
        $students = Student::list($this->params);
        $students = StudentResource::collection($students);
        return response()->json(['success' => true, 'data' => $students], 200);
    }

    public function store(StudentRequest $request)
    {
        Student::store($request);
        return response()->json([
            'success' => true,
            'data' => true,
            'message' => 'student created successfully'
        ], 200);
    }


    public function show(string $id)
    {
        $student = Student::find($id);
        $student = new ShowStudentResource($student);
        return response()->json(['success' => true, 'data' => $student], 200);

    }

    public function update(StudentRequest $request, string $id)
    {
        Student::store($request,$id);
        return response()->json([
            'success' => true,
            'data' => true,
            'message' => 'student updated successfully'
        ], 200);
    }


    public function destroy(string $id)
    {
        $student = Student::find($id);
        $student->delete();
        return response()->json([
            'success' => true,
            'data' => true,
            'message' => 'student deleted successfully'
        ], 200);
    }
}