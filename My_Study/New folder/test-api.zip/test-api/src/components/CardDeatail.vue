<template>
     <div class="card" v-for="user in users" :key="user">
      <div class="card-body">
        <h5 class="card-title">Name: {{ user.name }} </h5>
        <p>Email: {{ user.email }}</p>
        <p>Phone: {{ user.phone }} </p>
      </div>
      <CardFooterVue />
    </div>
</template>

<script>

import CardFooterVue from './CardFooter.vue'

export default {
    name:"CardDetail",
    components:{
        CardFooterVue
    },
    // props:{
    //     user:{}
    // }
    inject:["users"],
    computed:{
       injectUser(){
        return this.users;
       }
    }
    
        
    
}
</script>

<style scoped>
    .card{
        width: 30%;
    }
</style>