<template>
    <div class="card-footer">
        <p>Address: </p>
    </div>
</template>
<script>
export default {
    name:"CardFooter",
    // props:[
    //     "address"
    // ]
    inject:['address']
}
</script>