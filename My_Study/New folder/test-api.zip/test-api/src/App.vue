<template>
  <div class="container">
    <h1 class="text-danger">User List</h1>
    <div class="container">
      <CardDeatailVue  />
    </div>
    
  </div>
  
</template>

<script>
import CardDeatailVue from './components/CardDeatail.vue'


export default {
  name: 'App',
  components: {
    CardDeatailVue
  },
  data() {
    return {
      users:[
        {name:"leak",email:"leak@gmail.com",phone:"09943574",address:"Kandal"},
        {name:"le",email:"leak@gmail.com",phone:"09943574",address:"PP"},
        {name:"l",email:"leak@gmail.com",phone:"09943574",address:"Sr"},
        {name:"leak..",email:"leak@gmail.com",phone:"09943574",address:"KPT"},
      ]
    }
  },
  provide(){
    return {users:this.users};
  }
}
</script>

<style>
  .container{
    display: flex;
    flex-wrap: wrap;
    gap: 30px;
  }
</style>
