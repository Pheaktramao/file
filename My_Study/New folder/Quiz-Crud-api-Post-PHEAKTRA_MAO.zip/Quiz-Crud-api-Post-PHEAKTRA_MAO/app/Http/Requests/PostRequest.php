<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PostRequest extends DefaultRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function rules(): array
    {
        $rules = [
            'name' => 'required|string|max:255|min:2',
            'category_id' => 'required|integer|exists:categories,id',
        ];
        return $rules;
    }
}
