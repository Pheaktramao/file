<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class YonController extends Controller
{
    //
}
